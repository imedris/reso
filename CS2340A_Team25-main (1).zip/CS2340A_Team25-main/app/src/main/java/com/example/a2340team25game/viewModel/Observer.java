package com.example.a2340team25game.viewModel;

public interface Observer {
        void update(String collisionStatus);
}
