package com.example.a2340team25game.model.enemies;

import com.example.a2340team25game.model.Player;
import com.example.a2340team25game.viewModel.MovementStrategy;

public class Zombie implements Enemy {
    private MovementStrategy movementStrategy;
    private int health;
    private int movementSpeed;
    private int attack;

    public Zombie(int health, int movementSpeed, int attack, MovementStrategy movementStrategy) {
        this.health = health;
        this.movementSpeed = movementSpeed;
        this.attack = attack;
        this.movementStrategy = movementStrategy;
    }
    public void setMovementStrategy(MovementStrategy strategy) {
        this.movementStrategy = strategy;
    }

    public MovementStrategy getMovementStrategy() {
        return movementStrategy;
    }

    public void attack() {
        Player.getInstance().setHealth(Player.getInstance().getHealth() - attack);
    }
    public int getMoveSpeed() {
        return this.movementSpeed;
    }

    public int getHealth() {
        return health;
    }

    public int getAttack() {
        return attack;
    }

}
