package com.example.a2340team25game.viewModel;

public interface EnemyObserver {
    void updateEnemy(int playerX, int playerY);
}
