package com.example.a2340team25game.view;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.TextView;

import com.example.a2340team25game.R;
import com.example.a2340team25game.model.Player;
import com.example.a2340team25game.model.Score;
import com.example.a2340team25game.model.Leaderboard;


import java.util.ArrayList;

public class EndActivity extends AppCompatActivity {

    private TextView score1;
    private Leaderboard leaderboard;

    private TextView endingMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_end);
        endingMessage = findViewById(R.id.endingMessage);

        if (Player.getInstance().getHealth() == 0) {
            endingMessage.setText("You Lost!");
        }

        leaderboard = (Leaderboard) getIntent().getExtras().getSerializable("leaderboard");

        Button btnBackToMain = findViewById(R.id.btnBackToMain);

        score1 = findViewById(R.id.score1);
        ArrayList<Score> scores = new ArrayList<>();
        leaderboard.reverseInorderTraversal(scores);
        String result = "Most Recent Attempt: "
                + ((Score) getIntent().getExtras().getSerializable("recentScore"))
                .toString() + "\n";
        for (int i = 0; i < scores.size() && i < 5; i++) {
            result += "Attempt " + (i + 1) + ": " + scores.get(i).toString() + "\n";
        }
        score1.setText(result);

        btnBackToMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EndActivity.this, MainActivity.class);
                intent.putExtra("leaderboard", leaderboard);
                startActivity(intent);
                finish();
            }
        });
    }
}
