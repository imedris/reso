package com.example.a2340team25game.model;

import android.util.Log;

import com.example.a2340team25game.R;
import com.example.a2340team25game.view.GameActivity;
import com.example.a2340team25game.view.MapView;
import com.example.a2340team25game.viewModel.MoveInDirectionStrategy;
import com.example.a2340team25game.viewModel.MovementStrategy;
import com.example.a2340team25game.viewModel.Observer;
import com.example.a2340team25game.viewModel.Subject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Player implements MovementStrategy {
    private static Player player;
    private String name;
    private int health;
    private int difficulty;
    private int characterID;
    private Score score;
    private int xPos, yPos; // Character's position
    private static final int SPRITE_HEIGHT_AND_WIDTH = 128;
    private int moveSpeed;
    private MovementStrategy movementStrategy;

    private Player() {
        this.xPos = 0;
        this.yPos = 0;
        this.moveSpeed = 10;
        this.setMovementStrategy(new MoveInDirectionStrategy());

    }

    public static Player getInstance() {
        if(player == null) {
            player = new Player();
        }
        return player;
    }

    public void setMovementStrategy(MovementStrategy strategy) {
        this.movementStrategy = strategy;
    }

    public void moveStart(char direction) {
        if (movementStrategy != null) {
            movementStrategy.moveStart(direction);
        }
    }

    public void moveStop() {
        if (movementStrategy != null) {
            movementStrategy.moveStop();
        }
    }
    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public int getHealth() {
        return this.health;
    }

    public void setDifficulty(int difficulty) {
        this.difficulty = difficulty;
    }

    public int getDifficulty() {
        return this.difficulty;
    }

    public void setCharacterID(int characterID) {
        this.characterID = characterID;
    }

    public int getCharacterID() {
        return this.characterID;
    }
    public void setScore(int value, String name) {
        score = new Score(value, name);
    } // setScore

    public Score getScore() {
        if (this.score == null) {
            score = new Score(100, this.name);
        } // if
        return this.score;
    } // getScore

    public void setXPos(int xPos) {
        this.xPos = xPos;
    }
    public int getXPos() {
        return this.xPos;
    }

    public void setYPos(int yPos) {
        this.yPos = yPos;
    }
    public int getYPos() {
        return this.yPos;
    }

    public void setMoveSpeed(int moveSpeed) {
        this.moveSpeed = moveSpeed;
    }

    public int getMoveSpeed() {
        return this.moveSpeed;
    }

    public MovementStrategy getMovementStrategy() {
        return this.movementStrategy;
    }
}
