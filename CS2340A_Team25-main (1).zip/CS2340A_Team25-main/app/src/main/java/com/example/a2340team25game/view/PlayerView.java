package com.example.a2340team25game.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.view.View;

import com.example.a2340team25game.R;
import com.example.a2340team25game.model.Player;

public class PlayerView extends View {
    private Bitmap spriteSheet;
    Rect individualSprite;

    Rect playerPos;

    public PlayerView(Context context) {
        super(context);

        if(Player.getInstance().getCharacterID() == R.id.mage) {
            spriteSheet = BitmapFactory.decodeResource(getResources(), R.drawable.mage_ss);
        } else if(Player.getInstance().getCharacterID() == R.id.rogue) {
            spriteSheet = BitmapFactory.decodeResource(getResources(), R.drawable.rogue_ss);
        } else if(Player.getInstance().getCharacterID() == R.id.elf) {
            spriteSheet = BitmapFactory.decodeResource(getResources(), R.drawable.elf_ss);
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        individualSprite = new Rect(0, 0, 32, 32);

        playerPos = new Rect(Player.getInstance().getXPos(),
                Player.getInstance().getYPos() ,
                Player.getInstance().getXPos() + 128,
                Player.getInstance().getYPos() + 128);

        canvas.drawBitmap(spriteSheet, individualSprite, playerPos, null);

        this.setFocusable(true);
    }
}
