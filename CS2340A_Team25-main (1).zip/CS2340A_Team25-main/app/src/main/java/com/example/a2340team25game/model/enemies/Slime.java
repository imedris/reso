package com.example.a2340team25game.model.enemies;

import com.example.a2340team25game.model.Player;
import com.example.a2340team25game.viewModel.MovementStrategy;

public class Slime implements Enemy {
    private MovementStrategy movementStrategy;
    private int health;
    private int movementSpeed;
    private int attack;

    public Slime(int health, int movementSpeed, int attack, MovementStrategy movementStrategy) {
        this.health = health;
        this.movementSpeed = movementSpeed;
        this.attack = attack;
        this.movementStrategy = movementStrategy;
    }

    public MovementStrategy getMovementStrategy() {
        return movementStrategy;
    }

    public void setMovementStrategy(MovementStrategy movementStrategy) {
        this.movementStrategy = movementStrategy;
    }

    public void attack() {
        Player.getInstance().setHealth(Player.getInstance().getHealth() - attack);
    }

    public int getMoveSpeed() {
        return this.movementSpeed;
    }

    public int getHealth() {
        return health;
    }
}
