package com.example.a2340team25game.model.enemies;

public abstract class EnemySpawner {
    public Enemy spawnEnemy() {
        return createEnemy();
    }

    public abstract Enemy createEnemy();
}
