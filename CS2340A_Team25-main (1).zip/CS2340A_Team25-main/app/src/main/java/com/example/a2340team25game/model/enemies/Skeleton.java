package com.example.a2340team25game.model.enemies;

import com.example.a2340team25game.model.Player;
import com.example.a2340team25game.viewModel.MovementStrategy;

public class Skeleton implements Enemy {
    private MovementStrategy movementStrategy;
    private int health;
    private int movementSpeed;
    private int attack;

    public Skeleton(int health, int movementSpeed, int attack, MovementStrategy movementStrategy) {
        this.health = health;
        this.movementSpeed = movementSpeed;
        this.attack = attack;
        this.movementStrategy = movementStrategy;
    }
    public void setMovementStrategy(MovementStrategy strategy) {
        this.movementStrategy = strategy;
    }

    public MovementStrategy getMovementStrategy() {
        return movementStrategy;
    }

    public void attack() {
        Player.getInstance().setHealth(Player.getInstance().getHealth() - (attack + ((Player.getInstance().getDifficulty()) - 1)*attack));
    }

    @Override
    public int getMoveSpeed() {
        return this.movementSpeed;
    }

    public int getHealth() {
        return health;
    }

    public int getAttack() {
        return attack;
    }
}
