package com.example.a2340team25game.model;

import java.io.Serializable;
import java.util.ArrayList;

public class Leaderboard implements Serializable {
    private static Leaderboard leaderboard;

    private LeaderboardNode rootScore;
    private Leaderboard() {
        rootScore = null;
    } // Leaderboard
    public static Leaderboard getInstance() {
        if (leaderboard == null) {
            synchronized (Leaderboard.class) {
                if (leaderboard == null) {
                    leaderboard = new Leaderboard();
                } // if
            } // synchronized
        } // if
        return leaderboard;
    } // getInstance

    public void add(Score score) {
        rootScore = addRecursiveHelper(rootScore, score);
    }

    public LeaderboardNode addRecursiveHelper(LeaderboardNode curr, Score score) {
        if (curr == null) {
            return new LeaderboardNode(score);
        } else if (score.compareTo(curr.getScore()) > 0) {
            curr.setRight(addRecursiveHelper(curr.getRight(), score));
        } else if (score.compareTo(curr.getScore()) < 0 || score.compareTo(curr.getScore()) == 0) {
            curr.setLeft(addRecursiveHelper(curr.getLeft(), score));
        }
        updateLeaderboardNode(curr);
        return balanceLeaderboard(curr);
    }

    private void updateLeaderboardNode(LeaderboardNode curr) {
        int rHeight = -1;
        int lHeight = -1;
        if (curr.getRight() != null) {
            rHeight = curr.getRight().getHeight();
        }
        if (curr.getLeft() != null) {
            lHeight = curr.getLeft().getHeight();
        }
        curr.setHeight((Math.max(rHeight, lHeight) + 1));
        curr.setBalanceFactor(lHeight - rHeight);
    }

    private LeaderboardNode balanceLeaderboard(LeaderboardNode curr) {
        if (curr.getBalanceFactor() < -1) {
            if (curr.getRight().getBalanceFactor() > 0) {
                curr.setRight(rightRotate(curr.getRight()));
            }
            curr = leftRotate(curr);
        } else if (curr.getBalanceFactor() > 1) {
            if (curr.getLeft().getBalanceFactor() < 0) {
                curr.setLeft(leftRotate(curr.getLeft()));
            }
            curr = rightRotate(curr);
        }
        return curr;
    }

    private LeaderboardNode leftRotate(LeaderboardNode curr) {
        LeaderboardNode rightNode = curr.getRight();
        curr.setRight(rightNode.getLeft());
        rightNode.setLeft(curr);
        updateLeaderboardNode(curr);
        updateLeaderboardNode(rightNode);
        return rightNode;
    }

    private LeaderboardNode rightRotate(LeaderboardNode curr) {
        LeaderboardNode leftNode = curr.getLeft();
        curr.setLeft(leftNode.getRight());
        leftNode.setRight(curr);
        updateLeaderboardNode(curr);
        updateLeaderboardNode(leftNode);
        return leftNode;
    }
    public void reverseInorderTraversal(ArrayList<Score> scores) {
        recursiveReverseInorderTraversal(rootScore, scores);
    }
    public void recursiveReverseInorderTraversal(LeaderboardNode curr, ArrayList<Score> scores) {
        if (curr != null) {
            recursiveReverseInorderTraversal(curr.getRight(), scores);
            scores.add(curr.getScore());
            recursiveReverseInorderTraversal(curr.getLeft(), scores);
        }
    }

    public Score get(Score score) {
        return findHelper(rootScore, score);
    }

    private Score findHelper(LeaderboardNode curr, Score score) {
        if (curr == null) {
            return null;
        }
        if (score.compareTo(curr.getScore()) == 0) {
            return curr.getScore();
        } else if (score.compareTo(curr.getScore()) < 0) {
            return findHelper(curr.getLeft(), score);
        } else {
            return findHelper(curr.getRight(), score);
        }
    }


    /*    public void add(Score s) {
        scoreRecent = s;
        if (score1 == null) {
            score1 = s;
        } else if (score2 == null) {
           score2 = s;
        } else if (score3 == null) {
            score3 = s;
        } else if (score4 == null) {
            score4 = s;
        } else if (score5 == null) {
            score5 = s;
        } else {
            addFull(s);
            return;
        }
        sort();
    }

    private void sort() {
        if (score5 != null && score4 != null) {
            if (score5.compareTo(score4) > 0) {
                swap(score5, score4);
                if (score3 != null) {
                    if (score4.compareTo(score3) > 0) {
                        swap(score4, score3);
                        if (score2 != null) {
                            if (score3.compareTo(score2) > 0) {
                                swap(score2, score3);
                                if (score1 != null) {
                                    if (score2.compareTo(score1) > 0) {
                                        swap(score2, score1);
                                    }
                                }
                            }
                        }
                    }
                }
            } else if ((score4 != null && score3 != null)  && score4.compareTo(score3) > 0) {
                swap(score4, score3);
                if (score2 != null) {
                    if (score3.compareTo(score2) > 0) {
                        swap(score3, score2);
                        if (score1 != null) {
                            if (score2.compareTo(score1) > 0) {
                                swap(score2, score1);
                            }
                        }
                    }
                }
            } else if ((score3 != null && score2 != null) && score3.compareTo(score2) > 0) {
                swap(score3, score2);
                if (score1 != null) {
                    if (score2.compareTo(score1) > 0) {
                        swap(score2, score1);
                    }
                }
            } else if ((score2 != null && score1 != null) && score2.compareTo(score1) > 0) {
                swap(score2, score1);
            }
        }
    } // sort

    private void addFull(Score s) {
        if (s.compareTo(score1) > 0) {
            score5 = score4;
            score4 = score3;
            score3 = score2;
            score2 = score1;
            score1 = s;
        } else if (s.compareTo(score2) > 0) {
            score5 = score4;
            score4 = score3;
            score3 = score2;
            score2 = s;
        } else if (s.compareTo(score3) > 0) {
            score5 = score4;
            score4 = score3;
            score3 = s;
        } else if (s.compareTo(score4) > 0) {
            score5 = score4;
            score4 = s;
        } else if (s.compareTo(score5) > 0) {
            score5 = s;
        }
    }

    private void swap(Score a, Score b) {
        Score temp = a;
        a = b;
        b = temp;
    } // swap

    public Score getScore1() {
        return this.score1;
    }

    public Score getScore2() {
        return this.score2;
    }

    public Score getScore3() {
        return this.score3;
    }

    public Score getScore4() {
        return this.score4;
    }

    public Score getScore5() {
        return this.score5;
    }

    public Score getScoreRecent() {
        return this.scoreRecent;
    }*/
} // Leaderboard
