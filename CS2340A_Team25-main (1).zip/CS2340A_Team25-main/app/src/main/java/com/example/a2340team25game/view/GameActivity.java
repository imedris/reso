package com.example.a2340team25game.view;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
//import android.graphics.Bitmap;
//import android.graphics.BitmapFactory;
//import android.graphics.Matrix;
//import android.graphics.RectF;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
//import android.util.Log;
//import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
//import android.widget.FrameLayout;
//import android.widget.ImageView;
//import android.widget.LinearLayout;
//import android.widget.LinearLayout.LayoutParams;
//import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.a2340team25game.R;
import com.example.a2340team25game.model.Leaderboard;
import com.example.a2340team25game.model.Player;
//import com.example.a2340team25game.model.Score;
import com.example.a2340team25game.model.enemies.Enemy;
import com.example.a2340team25game.model.enemies.EnemySpawner;
import com.example.a2340team25game.model.enemies.SkeletonSpawner;
import com.example.a2340team25game.model.enemies.SlimeSpawner;
import com.example.a2340team25game.model.enemies.SpiderSpawner;
import com.example.a2340team25game.model.enemies.ZombieSpawner;
import com.example.a2340team25game.viewModel.EnemyObserver;
import com.example.a2340team25game.viewModel.MoveInDirectionStrategy;
//import com.example.a2340team25game.viewModel.MovementStrategy;
import com.example.a2340team25game.viewModel.Observer;
import com.example.a2340team25game.viewModel.PlayerSubject;
import com.example.a2340team25game.viewModel.PlayerViewModel;
import com.example.a2340team25game.viewModel.Subject;

import java.util.ArrayList;
import java.util.List;

public class GameActivity extends AppCompatActivity implements Subject, PlayerSubject {

    private TextView healthText;
    private TextView nameText;
    private TextView difficultyText;
    //private ImageView charView;
    private Context gameContext;
    private PlayerView playerView;
    private String healthString;
    private String nameString;
    private String difficultyString;
    private Button endButton;
    //private Button nextButton;
    private Button upButton;
    private Button downButton;
    private Button leftButton;
    private Button rightButton;
    private TextView scoreDisplay;
    private int time = 0;
    private boolean gameEnded = false;
    private static final int INITIAL_SCORE = 100;
    private Leaderboard leaderboard;
    private MapView mapView;
    //int currentScene = 0;
    private Handler handler = new Handler(Looper.getMainLooper());
    private static final int FRAME_RATE = 60; // Frames per second
    private Handler frameHandler;
    private static AssetManager assetManager;
    private Intent receivedIntent;
    private PlayerViewModel playerViewModel;
    private List<Observer> observers = new ArrayList<>();

    private List<EnemyObserver> enemyObservers = new ArrayList<>();
    private ViewGroup parentLayout;
    private ViewGroup.LayoutParams layoutParams;
    private EnemySpawner enemySpawner;//skeletonSpawner, slimeSpawner, spiderSpawner, zombieSpawner;
    private EnemyView enemyView1, enemyView2;//skeletonView1, slimeView1, spiderView1, zombieView1;

    Enemy enemy1, enemy2;//skeleton1, slime1, spider1, zombie1;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        gameContext = this;

        receivedIntent = getIntent();

        assetManager = getApplicationContext().getAssets();

        setContentView(R.layout.activity_game);

        mapView = new MapView(this, "Map1.csv", 1);

        playerViewModel = new PlayerViewModel(receivedIntent.getStringExtra("name"),
                receivedIntent.getIntExtra("health", 0),
                receivedIntent.getIntExtra("difficulty", 0),
                receivedIntent.getIntExtra("character", 0));

        registerObserver((MoveInDirectionStrategy) Player.getInstance().getMovementStrategy());

        playerView = new PlayerView(this);

        Player.getInstance().setXPos(1210);
        Player.getInstance().setYPos(600);

        frameHandler = new Handler();

        enemySpawner = new SkeletonSpawner();
        enemy1 = enemySpawner.spawnEnemy();
        enemyView1 = new EnemyView(this, 1210, 1376, enemy1);

        registerEnemyObserver(enemyView1.getEnemyViewModel());

        parentLayout = findViewById(R.id.gameScreen);

        layoutParams = new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        );

        parentLayout.addView(mapView, layoutParams);

        leaderboard = (Leaderboard) getIntent().getExtras().getSerializable("leaderboard");

        //time = 100;
        scoreDisplay = findViewById(R.id.scoreDisplay);
        //runs the screen every second
        handler.postDelayed(updateTextRunnable, 1000);

        //health display
        healthText = findViewById(R.id.health);
        healthString = "Health: " + Player.getInstance().getHealth();
        healthText.setText(healthString);

        //name display
        nameText = findViewById(R.id.name);
        nameString = "Name: " + Player.getInstance().getName();
        nameText.setText(nameString);

        //difficulty display
        if (Player.getInstance().getCharacterID() == 1) {
            difficultyString = ("Difficulty: Easy");
        } else if (Player.getInstance().getCharacterID() == 2) {
            difficultyString = ("Difficulty: Medium");
        } else if (Player.getInstance().getCharacterID() == 3) {
            difficultyString = ("Difficulty: Hard");
        }



        difficultyText = findViewById(R.id.difficulty);
        difficultyText.setText(difficultyString);

        parentLayout.addView(playerView, layoutParams);
        parentLayout.addView(enemyView1, layoutParams);

        upButton = findViewById(R.id.upButton);
        downButton = findViewById(R.id.downButton);
        leftButton = findViewById(R.id.leftButton);
        rightButton = findViewById(R.id.rightButton);

        upButton.setOnTouchListener(new View.OnTouchListener() {
            @SuppressLint("ClickableViewAccessibility")
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    Player.getInstance().moveStart('U');
                } else if (event.getAction() == MotionEvent.ACTION_UP) {
                    Player.getInstance().moveStop();
                }
                return true;
            }
        });

        downButton.setOnTouchListener(new View.OnTouchListener() {
            @SuppressLint("ClickableViewAccessibility")
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    Player.getInstance().moveStart('D');
                } else if (event.getAction() == MotionEvent.ACTION_UP) {
                    Player.getInstance().moveStop();
                }
                return true;
            }
        });

        leftButton.setOnTouchListener(new View.OnTouchListener() {
            @SuppressLint("ClickableViewAccessibility")
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    Player.getInstance().moveStart('L');
                } else if (event.getAction() == MotionEvent.ACTION_UP) {
                    Player.getInstance().moveStop();
                }
                return true;
            }
        });

        rightButton.setOnTouchListener(new View.OnTouchListener() {
            @SuppressLint("ClickableViewAccessibility")
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    Player.getInstance().moveStart('R');
                } else if (event.getAction() == MotionEvent.ACTION_UP) {
                    Player.getInstance().moveStop();
                }
                return true;
            }
        });

        frameHandler.postDelayed(frameUpdateRunnable, 1000 / FRAME_RATE);
    }
    //score display
    private Runnable updateTextRunnable = new Runnable() {
        @Override
        public void run() {

            int currentScore = INITIAL_SCORE - time;
            if (currentScore < 0) {
                currentScore = 0;
            }
            if (Player.getInstance().getHealth() == 0 && !gameEnded) {
                gameEnded = true;
                endGame(currentScore);
            }
            scoreDisplay.setText("Score: " + currentScore);
            time++;
            handler.postDelayed(this, 1000);
        }
    };

    public static AssetManager getAssetManager() {
        return assetManager;
    }

    private Runnable frameUpdateRunnable = new Runnable() {
        @Override
        public void run() {
            collisionHandling();
            notifyEnemyObservers(Player.getInstance().getXPos(), Player.getInstance().getYPos());
            playerView.invalidate();
            frameHandler.postDelayed(this, 1000 / FRAME_RATE);
            checkSwitchMap();
            healthString = "Health: " + Player.getInstance().getHealth();
            healthText.setText(healthString);

        }
    };
    private void endGame(int currentScore) {
        Player.getInstance().moveStop();
        Player.getInstance().setScore(currentScore, nameText.getText().toString());
        leaderboard.add(Player.getInstance().getScore());

        Intent i = new Intent(this, EndActivity.class);
        i.putExtra("leaderboard", leaderboard);
        i.putExtra("recentScore", Player.getInstance().getScore());
        startActivity(i);
        finish();
    }

    private void checkSwitchMap() {
        if (Player.getInstance().getYPos() < 10 && Player.getInstance().getXPos() < 2560
                && Player.getInstance().getXPos() > 2560 - 2 * 128 && mapView.getMapNumber() == 1) {
            mapView = new MapView(gameContext, "Map2.csv", 2);
            Player.getInstance().setYPos(12 * 128 - 6);

            removeEnemyObserver(enemyView1.getEnemyViewModel());
            parentLayout.removeView(enemyView1);
            enemySpawner = new SlimeSpawner();
            enemy1 = enemySpawner.spawnEnemy();
            enemyView1 = new EnemyView(this, 1210, 1000, enemy1);
            enemySpawner = new SpiderSpawner();
            enemy2 = enemySpawner.spawnEnemy();
            enemyView2 = new EnemyView(this, 300, 500, enemy2);
            parentLayout.addView(enemyView1, layoutParams);
            parentLayout.addView(enemyView2, layoutParams);
            registerEnemyObserver(enemyView1.getEnemyViewModel());
            registerEnemyObserver(enemyView2.getEnemyViewModel());

        } else if (Player.getInstance().getYPos() < 10 && Player.getInstance().getXPos() < 1376
                && Player.getInstance().getXPos() > 1184 && mapView.getMapNumber() == 2) {
            mapView = new MapView(gameContext, "Map3.csv", 3);
            Player.getInstance().setYPos(12 * 128 - 6);

            removeEnemyObserver(enemyView1.getEnemyViewModel());
            removeEnemyObserver(enemyView2.getEnemyViewModel());
            parentLayout.removeView(enemyView1);
            parentLayout.removeView(enemyView2);
            enemySpawner = new ZombieSpawner();
            enemy1 = enemySpawner.spawnEnemy();
            enemyView1 = new EnemyView(this, 300, 500, enemy1);
            parentLayout.addView(enemyView1, layoutParams);
            registerEnemyObserver(enemyView1.getEnemyViewModel());

        } else if (Player.getInstance().getXPos() < 10 && Player.getInstance().getYPos() < 896
                && Player.getInstance().getYPos() > 640 && mapView.getMapNumber() == 3) {
            if (!gameEnded) {
                gameEnded = true;

                Player.getInstance().moveStop();
                int currentScore = INITIAL_SCORE - time;
                if (currentScore < 0) {
                    currentScore = 0;
                }

                Player.getInstance().setScore(currentScore, nameText.getText().toString());


                leaderboard.add(Player.getInstance().getScore());

                Intent i = new Intent(this, EndActivity.class);
                i.putExtra("leaderboard", leaderboard);
                i.putExtra("recentScore", Player.getInstance().getScore());
                startActivity(i);
                finish();
            }

        }
    }
    public void collisionHandling() {
        boolean[][] collisionMap = mapView.getMap().getCollisionMap();
        int playerX = Player.getInstance().getXPos();
        int playerY = Player.getInstance().getYPos();

        if(collisionMap[playerY + 64][playerX]) { //Left Center
            notifyObservers("Left Collision");
            //Log.v("Col", "Left");
        } else {
            notifyObservers("No Left Collision");
        }
        if (collisionMap[playerY][playerX + 64]) { //Top Center
            notifyObservers("Top Collision");
            //Log.v("Col", "Top");
        } else {
            notifyObservers("No Top Collision");
        }
        if (collisionMap[playerY + 64][playerX + 128]) { //Right Center
            notifyObservers("Right Collision");
            //Log.v("Col", "Right");
        } else {
            notifyObservers("No Right Collision");
        }
        if (collisionMap[playerY + 128][playerX + 64]) { //Bottom Center
            notifyObservers("Bottom Collision");
            //Log.v("Col", "Bottom");
        } else {
            notifyObservers("No Bottom Collision");
        }

    }

    @Override
    public void registerObserver(Observer observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers(String collisionStatus) {
        for (Observer observer : observers) {
            observer.update(collisionStatus);
        }
    }

    @Override
    public void registerEnemyObserver(EnemyObserver enemyObserver) {
        enemyObservers.add(enemyObserver);
    }

    @Override
    public void removeEnemyObserver(EnemyObserver enemyObserver) {
        enemyObservers.remove(enemyObserver);
    }

    @Override
    public void notifyEnemyObservers(int playerX, int playerY) {
        for (EnemyObserver enemyObserver : enemyObservers) {
            enemyObserver.updateEnemy(playerX, playerY);
        }
    }
    public boolean isRunning() {
        if (!gameEnded) {
            return true;
        }
        return false;
    }
}
