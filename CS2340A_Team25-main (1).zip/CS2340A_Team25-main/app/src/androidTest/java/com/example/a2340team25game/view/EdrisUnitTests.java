package com.example.a2340team25game.view;

import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.intent.Intents.intended;
import static androidx.test.espresso.intent.matcher.IntentMatchers.hasComponent;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.isRoot;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

import static org.junit.Assert.assertEquals;

import android.content.Intent;
import android.os.Looper;

import androidx.test.core.app.ActivityScenario;
import androidx.test.core.app.ApplicationProvider;
import androidx.test.espresso.Espresso;
import androidx.test.espresso.intent.Intents;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.a2340team25game.R;
import com.example.a2340team25game.model.Leaderboard;
import com.example.a2340team25game.model.Score;
import com.example.a2340team25game.viewModel.MoveInDirectionStrategy;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.lang.reflect.Field;

@RunWith(AndroidJUnit4.class)
public class EdrisUnitTests {

    @Before
    public void setUp() {
        // Initialize Espresso-Intents before each test
        Intents.init();
        moveInDirectionStrategy = new MoveInDirectionStrategy();

    }


    @After
    public void tearDown() {
        Intents.release();
    }

    @Test
    public void checkBackToMainButton_NavigatesToMainActivity() {
        // Obtain a Leaderboard instance
        Leaderboard leaderboard = Leaderboard.getInstance();

        // Create a Score object
        Score recentScore = new Score(100, "PlayerName");

        // Add the Score object to the Leaderboard
        leaderboard.add(recentScore);

        // Create an Intent with the necessary extras for EndActivity
        Intent endActivityIntent = new Intent(ApplicationProvider.getApplicationContext(), EndActivity.class);
        endActivityIntent.putExtra("leaderboard", leaderboard);
        endActivityIntent.putExtra("recentScore", recentScore);

        // Use ActivityScenario to launch EndActivity
        try (ActivityScenario<EndActivity> scenario = ActivityScenario.launch(endActivityIntent)) {

            // Verify that the 'Back To Home' button is displayed
            Espresso.onView(withId(R.id.btnBackToMain))
                    .check(matches(isDisplayed()));

            Espresso.onView(isRoot()).perform(closeSoftKeyboard());
            // Perform a click action on the 'Back To Home' button
            Espresso.onView(withId(R.id.btnBackToMain)).perform(click());

            // Verify that the intended intent is to launch MainActivity
            intended(hasComponent(MainActivity.class.getName()));


        }
    }




    // Test 2
    @Test
    public void checkThanksForPlayingText_isDisplayed() {
        // Obtain a Leaderboard instance
        Leaderboard leaderboard = Leaderboard.getInstance();

        // Create a Score object
        Score recentScore = new Score(100, "PlayerName");

        // Add the Score object to the Leaderboard
        leaderboard.add(recentScore);

        // Create an Intent with the necessary extras
        Intent intent = new Intent(ApplicationProvider.getApplicationContext(), EndActivity.class);
        intent.putExtra("leaderboard", leaderboard);
        intent.putExtra("recentScore", recentScore);

        // Launch the current activity with the prepared Intent
        try (ActivityScenario<EndActivity> scenario = ActivityScenario.launch(intent)) {

            // Check if the text "Thanks For Playing!" is displayed
            Espresso.onView(withText("You Won!"))
                    .check(matches(isDisplayed()));
        }
    }




    private MoveInDirectionStrategy moveInDirectionStrategy;



    @Test
    public void testMoveStart() throws NoSuchFieldException, IllegalAccessException {
        // Ensure a Looper is prepared for this thread.
        if (Looper.myLooper() == null) {
            Looper.prepare();
        }

        char expectedDirection = 'U';
        moveInDirectionStrategy.moveStart(expectedDirection);

        Field field = MoveInDirectionStrategy.class.getDeclaredField("directionMoving");
        field.setAccessible(true);
        char actualDirection = (char) field.get(moveInDirectionStrategy);

        assertEquals(expectedDirection, actualDirection);
    }


    @Test
    public void testMoveStop() throws NoSuchFieldException, IllegalAccessException {
        if (Looper.myLooper() == null) {
            Looper.prepare();
        }

        // Start moving in a direction
        moveInDirectionStrategy.moveStart('U');

        // Stop the movement
        moveInDirectionStrategy.moveStop();

        Field field = MoveInDirectionStrategy.class.getDeclaredField("directionMoving");
        field.setAccessible(true);
        char actualDirection = (char) field.get(moveInDirectionStrategy);

        // checking if direction is changed to 0
        assertEquals('\0', actualDirection);
    }


}
